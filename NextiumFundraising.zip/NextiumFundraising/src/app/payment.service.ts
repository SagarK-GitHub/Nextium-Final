import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FundraiserService } from './fundraiser.service';
import { transition } from '@angular/animations';
import { catchError, Observable, throwError } from 'rxjs';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})

export class PaymentService {
  private apiUrl = 'https://localhost:44396/api';
  paymntdata: any;
  amnt: number = 0;

  constructor(private http:HttpClient,private snackBar:MatSnackBar,private router: Router,private service:FundraiserService) { }

  payWithRazorpay(amount: number,Pdata:any) {
    this.amnt= amount;
    this.paymntdata = Pdata;
    this.http.post('https://localhost:44396/create-order',{amount}).subscribe((order:any)=>{
    const options: any = {
      key: 'rzp_test_UpCAVDOPC6txDy', // Replace with your Razorpay Key ID
      amount: amount * 100, // Amount is in currency subunits. Default currency is INR.
      currency: 'INR',
      name: 'Nextium',
      description: 'For Social Cause',
      image: '../../assets/logo1.jpg', // Optional
      order_id: order.id, // Order ID from backend
          handler: (response: any) => {
            this.showSuccess(response);
          },
          prefill: {
            name: '',
            email: '',
            contact: ''
          },
          notes: {
            address: 'Your Company Address'
          },
          theme: {
            color: '#F37254'
          },
          modal: {
            ondismiss: () => {
              this.showError('Payment cancelled');
            }
          }
        };

        const rzp1 = new (window as any).Razorpay(options);
        rzp1.open();
      }, (error) => {
        this.showError('Failed to create order');
      });
  }

   showSuccess(response: any) {
   
    this.paymntdata.donations[0].amount = (Number(this.amnt));
    this.paymntdata.donations[0].transactionId = response.razorpay_payment_id;

    this.snackBar.open('Payment successful! Transaction ID: ' + response.razorpay_payment_id, 'Close', { 
      duration: 5000,
    });
    this.service.Donors(this.paymntdata);
    this.router.navigate(['overview/home',this.paymntdata])  
  }



  private showError(message: string) {
    this.snackBar.open('Error: ' + message, 'Close', {
      duration: 5000,
    });
  }

  // Donors(body: any): Observable<any> {
  //   const url = `${this.apiUrl}/Donors`;
  //   return this.http.post<any>(url, body).pipe(catchError(this.handleError));
  // }

  private handleError(err: any) {
    let errorMessage: string;

    if (err.error instanceof ErrorEvent) {
      errorMessage = `An error occurred: ${err.error.message}`;
    } else {
     errorMessage = err.error;
    }
    return throwError(errorMessage);
  }

  
}


