// import { style } from '@angular/animations';
// import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
// import { Router } from '@angular/router';
// declare var paypal: any;

// @Component({
//   selector: 'app-payment',
//   templateUrl: './payment.component.html',
//   styleUrl: './payment.component.scss'
// })
// export class PaymentComponent implements OnInit {

//   amount = 5

//   @ViewChild('paymentRef', { static: true }) paymentRef!: ElementRef;

//   ngOnInit(): void {
//     window.paypal.Buttons(
//       {
//         style: {
//           layout: 'horizontal',
//           color: 'blue',
//           shape: 'rect',
//           label: 'paypal',
//         },
//         createOrder: (data: any, actions: any) => {
//           return actions.order.create({
//             purchase_units: [
//               {
//                 amount: {
//                   value: this.amount.toString(),
//                   // currency_code: 'USD'
//                 }
//               }
//             ]
//           });
//         },
//         onApprove: (data: any, actions: any) => {
//           return actions.order.capture().then((details: any) => {
//             console.log(details);
//             if (details.status == 'COMPLETED') {


//             }
//           });
//         },
//         onError: (error: any) => {
//           console.log(error);

//         }
//       }
//     ).render(this.paymentRef.nativeElement);

//   }

//   cancel() {

//   }



// }

// import { Component } from '@angular/core';
// import { PaymentService } from '../payment.service';

// @Component({
//   selector: 'app-payment',
//   template: `<button (click)="pay()">Pay Now</button>`,
// })
// export class PaymentComponent {

//   constructor(private paymentService: PaymentService) { }

//   pay() {
//     const amount = 500; // Amount to be paid
//     this.paymentService.payWithRazorpay(amount);
//   }
// }

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PaymentService } from '../payment.service';
import { Subscription } from 'rxjs';
import { FundraiserService } from '../fundraiser.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.scss']
})
export class PaymentComponent implements OnInit {
  paymentForm: FormGroup;
  private subscription: Subscription = new Subscription();
  paymntdata: any;

  constructor(private fb: FormBuilder, private paymentService: PaymentService,private service: FundraiserService) {
    this.paymentForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      contact: ['', Validators.required],
      amount: ['', [Validators.required, Validators.min(1)]]
    });
  }

  ngOnInit(): void {
    this.subscription.add(this.service.Getdonamont$.subscribe(x=>{
      if(x){
        this.paymntdata = x
        this.paymentForm.controls['name'].setValue(x?.firstName + ' ' + x?.lastName);
        this.paymentForm.controls['email'].setValue(x?.email);
        this.paymentForm.controls['contact'].setValue(x?.phoneNumber);
        this.paymentForm.controls['amount'].setValue(x?.donations[0].amount);
      }
    }))
    
  }

  pay() {
    if (this.paymentForm.valid) {
      const formValues = this.paymentForm.value;
      this.paymentService.payWithRazorpay(formValues.amount,this.paymntdata);
    }
  }
}

