import { Component } from '@angular/core';

@Component({
  selector: 'app-cause',
  templateUrl: './cause.component.html',
  styleUrl: './cause.component.scss'
})
export class CauseComponent {

}
